﻿
Partial Class _Default
    Inherits Page
	
	 Private Sub _Default_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Threading.Thread.Sleep(3000)
	Response.Write(“New Session : “ & Session.isnewSession)
		Session(“New”) = “New”
    End Sub

End Class


