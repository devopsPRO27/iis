Partial Class _Default
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
		� Response.Write(System.Security.Principal.WindowsIdentity.GetCurrent.Name)
		Response.Write(�New Session : � & Session.isnewSession)
		Session(�New�) = �New�
	End Sub
End Class